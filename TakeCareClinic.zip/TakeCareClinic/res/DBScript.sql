
/*************************************************************************************************************************************
 * File: DBScript.sql
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
CREATE TABLE Patient(
	patient_id NUMBER(5) PRIMARY KEY,
	patient_name VARCHAR2(20) NOT NULL,
	age NUMBER(3) NOT NULL,
	phone VARCHAR2(10) NOT NULL UNIQUE,
	description VARCHAR2(80) NOT NULL,
	consultation_date DATE NOT NULL
	);
	
	CREATE SEQUENCE patient_Id_Seq
	START WITH 1000
	INCREMENT BY 1;