package com.cg.tcc.util;

/*************************************************************************************************************************************
 * File: ConnectionProvider.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.tcc.util.ConnectionProvider;

public class ConnectionProvider {

	private String uid;
	private String pwd;
	private String url;
	private String driver;

	private static ConnectionProvider cp;

	private ConnectionProvider(String configFileName)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		Properties props = new Properties();
		props.load(new FileInputStream(configFileName));

		uid = props.getProperty("db.uid");
		pwd = props.getProperty("db.pwd");
		url = props.getProperty("db.url");
		driver = props.getProperty("db.driver");

		Class.forName(driver);
	}

	public static ConnectionProvider getInstance(String configFileName)
			throws FileNotFoundException, ClassNotFoundException, IOException {
		if (cp == null)
			cp = new ConnectionProvider(configFileName);
		return cp;
	}

	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, uid, pwd);
	}
}
