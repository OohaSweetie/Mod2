package com.cg.tcc.ui;
/*************************************************************************************************************************************
 * File: UserMenu.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
public enum UserMenu {
	ADD,LIST,EXIT;
}
