package com.cg.tcc.exception;

/*************************************************************************************************************************************
 * File: ClinicException.java
 * Version: 1.0

 * Description: to add and list patients in TakeCare CLinic

 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
@SuppressWarnings("serial")
public class ClinicException extends Exception {

	public ClinicException(String message) {
		super(message);
	}
}
