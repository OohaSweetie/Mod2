package com.cg.groapp.util;

import java.io.*;
import java.sql.*;
import java.util.Properties;

import com.cg.groapp.exception.EnquiryException;

public class DBUtil 
{
	static String dbunm=null;
	static String dbpwd=null;
	static String url;
	
	public static Connection getCon() throws IOException,EnquiryException,SQLException
	{
		Connection con=null;
		Properties dbInfoProps=DBUtil.getProps();
		url=dbInfoProps.getProperty("dbURL");
		dbunm=dbInfoProps.getProperty("dbUserName");
		dbpwd=dbInfoProps.getProperty("dbPwd");
		if(con==null)
		{
			con=DriverManager.getConnection(url,dbunm,dbpwd);
		}
		return con;
	}
	public static Properties getProps() throws IOException,EnquiryException
	{
		Properties props=null;
		FileReader fr=null;
		props=new Properties();
		fr=new FileReader("resources/dbInfo.properties");
		props.load(fr);
		return props;
	}
}
