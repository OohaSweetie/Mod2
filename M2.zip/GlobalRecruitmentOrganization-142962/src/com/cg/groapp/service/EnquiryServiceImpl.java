package com.cg.groapp.service;

import java.util.regex.Pattern;

import com.cg.groapp.bean.Enquiry;
import com.cg.groapp.dao.*;
import com.cg.groapp.exception.EnquiryException;

public class EnquiryServiceImpl implements EnquiryService 
{
	EnquiryDao ed=null;
	public EnquiryServiceImpl() 
	{
		ed=new EnquiryDaoImpl();
	}
	
	@Override
	public int addEnquiry(Enquiry enq) throws EnquiryException 
	{
		return ed.addEnquiry(enq);
	}

	@Override
	public Enquiry getEnquiryDetails(int enquiryId)	throws EnquiryException 
	{
		return ed.getEnquiryDetails(enquiryId);
	}

	@Override
	public boolean isValidEnquiry(Enquiry enq) throws EnquiryException 
	{
		String firstName=enq.getFirstName();
		String lastName=enq.getLastName();
		String contact=String.valueOf(enq.getContactNo());
		String domainName=enq.getDomain();
		String location=enq.getCity();
		String fnamePattern="[A-Z][a-z]+";
		String lnamePattern="[A-Z][a-z]+";
		String contactPattern="[789][0-9]{9}$";
		String domainPattern="[A-Z][A-Za-z]+";
		String locationPattern="[A-Z][a-z]+";
		if(Pattern.matches(fnamePattern, firstName) && Pattern.matches(lnamePattern, lastName))
		{
			if(Pattern.matches(contactPattern, contact))
			{
				if(Pattern.matches(domainPattern, domainName))
				{
					if(Pattern.matches(locationPattern, location))
					{
						return true;
					}
					else
					{
						throw new EnquiryException("Location Name should be alphabets and starts with capital letter.");
					}
				}
				else
				{
					throw new EnquiryException("Domain Name should be alphabets and starts with capital letter.");
				}
			}
			else
			{
				throw new EnquiryException("Contact Number should be a 10-digit number and starts with 7,8 or 9");
			}
		}
		else
		{
			throw new EnquiryException("First name and last name should be alphabets and starts with capital letter.");
		}
	}
}
