package com.cg.groapp.dao;

import java.sql.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.groapp.bean.Enquiry;
import com.cg.groapp.exception.EnquiryException;
import com.cg.groapp.util.DBUtil;

public class EnquiryDaoImpl implements EnquiryDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Enquiry enq=new Enquiry();
	Logger groLogger=null;
	public EnquiryDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		groLogger=Logger.getLogger("EnquiryDaoImpl.class");
	}
	@Override
	public int addEnquiry(Enquiry ee) throws EnquiryException 
	{
		String insertQry="INSERT INTO enquiry values(?,?,?,?,?,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,generateEnquiryId());
			pst.setString(2,ee.getFirstName());
			pst.setString(3,ee.getLastName());
			pst.setLong(4,ee.getContactNo());
			pst.setString(5,ee.getDomain());
			pst.setString(6,ee.getCity());
			dataAdded=pst.executeUpdate();
			groLogger.info("enquiry details inserted "+ee);
		} 
		catch (Exception e) 
		{
			throw new EnquiryException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				groLogger.error("This is exception :"+e.getMessage());
				throw new EnquiryException(e.getMessage());
			}	
		}
		return dataAdded+enq.getEnquiryId();
	}

	@Override
	public Enquiry getEnquiryDetails(int enquiryId) throws EnquiryException 
	{
		Enquiry enquiry=null;
		String selectQry="SELECT * FROM enquiry where enqryid=?";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setInt(1, enquiryId);
			rs=pst.executeQuery();
			groLogger.info("ENQUIRY RECORD OF ID "+enquiryId+" IS :");
			rs.next();
			enquiry=new Enquiry(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getLong(4),rs.getString(5),rs.getString(6));
			groLogger.info(enquiry);
		} 
		catch (Exception e) 
		{
			throw new EnquiryException("Sorry no details found!!");
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (SQLException e) 
			{
				groLogger.error("This is exception :"+e.getMessage());
				throw new EnquiryException(e.getMessage());
			}
		}
		return enquiry;
	}
	
	public int generateEnquiryId() throws EnquiryException 
	{
		String qry="Select enquiries.NEXTVAL from dual";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			enq.setEnquiryId(generatedVal);
		} 
		catch (Exception e) 
		{
			throw new EnquiryException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e) 
			{
				throw new EnquiryException(e.getMessage());
			}
		}
		return generatedVal;
	}
}
