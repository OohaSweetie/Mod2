package com.cg.groapp.dao;

import com.cg.groapp.bean.Enquiry;
import com.cg.groapp.exception.EnquiryException;

public interface EnquiryDao 
{
	public int addEnquiry(Enquiry enq) throws EnquiryException;
	public Enquiry getEnquiryDetails(int enquiryId) throws EnquiryException;
	public int generateEnquiryId() throws EnquiryException;
}
