package com.cg.groapp.junit;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.groapp.bean.Enquiry;
import com.cg.groapp.dao.*;
import com.cg.groapp.exception.EnquiryException;

import junit.framework.Assert;

public class EnquiryTests {
	
	static EnquiryDao enqDao=null;
	static Enquiry enq=null;
	@BeforeClass
	public static void beforeClass() throws EnquiryException
	{
		enqDao=new EnquiryDaoImpl();
		enq=new Enquiry(enqDao.generateEnquiryId(),"Vardhani","Kalaga",8796541203L,"Java","Hyderabad");
	}
	@Test
	public void testAddEnq1() throws EnquiryException
	{
		Assert.assertNotNull(enqDao.addEnquiry(enq));
	}
	@Test(expected=Exception.class)
	public void testAddEnq2() throws EnquiryException
	{
		Assert.assertEquals(1,enqDao.addEnquiry(enq));
	}
	@Test
	public void testSelectEnq1() throws EnquiryException
	{
		Assert.assertNotNull(enqDao.getEnquiryDetails(1001));
	}
	@Test
	public void testSelectEnq2() throws EnquiryException
	{
		Assert.assertNotNull(enqDao.getEnquiryDetails(1003));
	}
}
