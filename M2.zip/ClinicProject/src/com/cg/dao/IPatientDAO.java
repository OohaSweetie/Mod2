package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.PatientBean;
import com.cg.exception.PatientException;

public interface IPatientDAO 
{
int addPatientDetails(PatientBean patient) throws PatientException;
PatientBean getPatientDetails(int patientId) throws PatientException;
int generatePatientId() throws PatientException;
int deletePatient(int patientId) throws PatientException;
ArrayList<PatientBean> getAllPatientDetails() throws PatientException;
 ArrayList<Integer>  getAllPatIds() throws PatientException;
}
