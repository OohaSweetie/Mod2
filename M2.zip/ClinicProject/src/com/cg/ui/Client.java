package com.cg.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.PatientBean;
import com.cg.exception.PatientException;
import com.cg.service.IPatientService;
import com.cg.service.PatientService;

public class Client
{
	static IPatientService applyService=new PatientService();;
	static Scanner sc=new Scanner(System.in);
	static PatientBean patient=null;
	public static void main(String[] args) 
	{
		int choice=0;
		while(true)
		{
			System.out.println("Select an operation ");
			System.out.println("1.Enter Details "
					+ "\n2.View Details based on Patient Id "
					+ "\n3.Delete"
					+ "\n4.fetch"
					
					+ "\n0.Exit");
			System.out.println("Please enter a choice : ");

			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	addPatientDetails();	
			break;

			case 2:	getPatientDetailsById();
			break;
			case 3: delete();
			break;
			case 4: fetch();
			break;
			
			case 0: exit();

			break;

			default : System.out.println("Invalid Choice Enter");

			}
		}
	}
	private static void fetch() 
	{
		try
		{
			ArrayList<PatientBean> pList=applyService.getAllPatientDetails();
			for(PatientBean p:pList)
			{
				System.out.println(p);
			}
		}
		catch(PatientException e)
		{
			System.out.println("Some Exception while fetching data");
		}	
		
	}
	private static void delete() 
	{
		System.out.println("Enter patient id:");
		int pid=sc.nextInt();
		try
		{
			PatientBean p=new PatientBean();
			p.setPatientId(pid);
			int dataDeleted=applyService.deletePatient(pid);
			if(dataDeleted==1)
			{
				System.out.println("Data Deleted:");
			}
			else
			{
				System.out.println("Some Exceptions Occured");
			}
		}   
		catch(PatientException e)
		{
			System.out.println("Some Exception while fetching data");
		}
		
	}
	public static void exit()
	{
		System.out.println("Thank you for applying !!");
		System.exit(0);

	}
	public static  void getPatientDetailsById() 
	{
		try 
		{
			System.out.println("Enter your Patient Id :");
			int patientId=sc.nextInt();
			if(applyService.validatePatientId(patientId))
			{
				System.out.println(applyService.getPatientDetails(patientId));
			}
			else
			{
				System.out.println("Invalid ID");
			}
		} 
		catch (PatientException e) 
		{			
			System.out.println(e.getMessage());
		}

	}
	public static  void addPatientDetails()
	{
		int dataAdded=0;
		System.out.println("Enter Name of the patient :");
		String patientName = sc.next();
		System.out.println("Enter patient age: ");
		int pAge=sc.nextInt();
		System.out.println("Enter phone Number: ");
		String phoneNo=sc.next();
		System.out.println("Enter description: ");
		String descr=sc.next();

		patient  = new PatientBean();
		try 
		{
			patient.setPatientId(applyService.generatePatientId());
			patient.setPatientName(patientName);
			patient.setpAge(pAge);
			patient.setPhoneNo(phoneNo);
			patient.setDescr(descr);

			if(applyService.isValidPatient(patient))
			{

				dataAdded=applyService.addPatientDetails(patient);
				if(dataAdded==1)
				{
					System.out.println("Thank you "+patient.getPatientName()+" "
							+ ""+patient.getpAge()+""+patient.getPhoneNo()
							+patient.getDescr());
				}			
				else
				{
					System.out.println("May Have some exception while Inserting Data");
				}

			}
		}
		catch (PatientException e) 
		{
			System.out.println(e.getMessage());
		}

	}


}

