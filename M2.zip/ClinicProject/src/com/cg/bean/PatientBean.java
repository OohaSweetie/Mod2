package com.cg.bean;

import java.time.LocalDate;

public class PatientBean
{
	private int patientId;
	private String patientName;
	private int pAge;
	private String phoneNo;
	private String descr;
	private LocalDate consultDate;
	public PatientBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public int getpAge() {
		return pAge;
	}
	public void setpAge(int pAge) {
		this.pAge = pAge;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getDescr() {
		return descr;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	public LocalDate getConsultDate() {
		return consultDate;
	}
	public void setConsultDate(LocalDate consultDate) {
		this.consultDate = consultDate;
	}
	public PatientBean(int patientId, String patientName, int pAge,
			String phoneNo, String descr, LocalDate consultDate) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.pAge = pAge;
		this.phoneNo = phoneNo;
		this.descr = descr;
		this.consultDate = consultDate;
	}
	@Override
	public String toString() {
		return "PatientBean [patientId=" + patientId + ", patientName="
				+ patientName + ", pAge=" + pAge + ", phoneNo=" + phoneNo
				+ ", descr=" + descr + ", consultDate=" + consultDate + "]";
	}
	
	
	

}
