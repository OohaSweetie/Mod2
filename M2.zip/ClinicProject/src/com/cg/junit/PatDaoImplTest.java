package com.cg.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bean.PatientBean;
import com.cg.dao.IPatientDAO;
import com.cg.dao.PatientDAO;
import com.cg.exception.PatientException;







public class PatDaoImplTest
{
	 static IPatientDAO pDao=null;
	 static PatientBean p =null;
	 @BeforeClass	
	   public static void beforeClass() throws PatientException
	   {
		 pDao=new PatientDAO();
		 p=new PatientBean(pDao.generatePatientId(),"AAA",10, "9874563210", "cold", null);
		   
	   }
	 @Test
		public void testAddEnq1() throws PatientException
		{
			Assert.assertNotNull(pDao.addPatientDetails(p));
		}
	 @Test(expected=Exception.class)
		public void testAddEnq2() throws PatientException
		{
			Assert.assertEquals(1,pDao.addPatientDetails(p));
		}
	 @Test
		public void testSelectEnq1() throws PatientException
		{
			Assert.assertNotNull(pDao.getPatientDetails(1012));
		}
	 @Test
		public void testSelectEnq2() throws PatientException
		{
			Assert.assertNotNull(pDao.getPatientDetails(1003));
		}
	 	
}
