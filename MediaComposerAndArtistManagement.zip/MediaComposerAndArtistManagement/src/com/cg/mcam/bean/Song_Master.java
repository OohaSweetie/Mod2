package com.cg.mcam.bean;

import java.sql.Date;

public class Song_Master

{
	private int song_id;
	private String song_name;
	private String song_duration;
	private int Created_by;
	private Date Created_on;
	private int Updated_by;
	private Date Updadted_on;


	public int getSong_id() 
	{
		return song_id;
	}
	public void setSong_id(int song_id) 
	{
		this.song_id = song_id;
	}
	public String getSong_name() 
	{
		return song_name;
	}
	public void setSong_name(String song_name) 
	{
		this.song_name = song_name;
	}
	public String getSong_duration() 
	{
		return song_duration;
	}
	public void setSong_duration(String song_duration) 
	{
		this.song_duration = song_duration;
	}
	public int getCreated_by() 
	{
		return Created_by;
	}
	public void setCreated_by(int created_by) 
	{
		Created_by = created_by;
	}
	public Date getCreated_on() 
	{
		return Created_on;
	}
	public void setCreated_on(Date created_on) 
	{
		Created_on = created_on;
	}
	public int getUpdated_by() 
	{
		return Updated_by;
	}
	public void setUpdated_by(int updated_by) 
	{
		Updated_by = updated_by;
	}
	public Date getUpdadted_on() 
	{
		return Updadted_on;
	}
	public void setUpdadted_on(Date updadted_on) 
	{
		Updadted_on = updadted_on;
	}
	public Song_Master() {
		super();

	}
	public Song_Master(int song_id, String song_name, String song_duration,
			int Created_by, Date Created_on, int Updated_by, Date Updadted_on) {
		super();
		this.song_id = song_id;
		this.song_name = song_name;
		this.song_duration = song_duration;
		Created_by = Created_by;
		Created_on = Created_on;
		Updated_by = Updated_by;
		Updadted_on = Updadted_on;
	}

	@Override
	public String toString() 
	{
		return "Song_Master [song_id=" + song_id + ", song_name=" + song_name
				+ ", song_duration=" + song_duration + ", Created_by="
				+ Created_by + ", Created_on=" + Created_on + ", Updated_by="
				+ Updated_by + ", Updadted_on=" + Updadted_on + "]";
	}




}
