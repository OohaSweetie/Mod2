package com.cg.mcam.dao;


import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.print.attribute.standard.Media;

import com.cg.mcam.bean.Artist_Master;
import com.cg.mcam.bean.Composer_Master;
import com.cg.mcam.bean.Song_Master;
import com.cg.mcam.exception.MediaException;

public interface MediaDao 
{
	public int addSongs(Song_Master sm) throws MediaException;
	public ArrayList<Song_Master> getAllSongs () throws MediaException;
	public int deleteSong(int id) throws MediaException;
	public int addComposer(Composer_Master cm) throws MediaException;
	public int addArtist(Artist_Master am) throws MediaException;
	public Song_Master getSong(int song_id) throws MediaException, Exception;
	public Composer_Master getComposer(int composer_Id) throws MediaException;
	public Artist_Master getArtist(int artist_Id) throws MediaException;
	
	
	/*************************Generating Id***********************************************/
	public int generateSongId() throws MediaException;
	public int generateComposerId() throws MediaException;
	public int generateArtistId() throws MediaException;
}
