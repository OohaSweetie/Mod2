package com.cg.mcam.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mcam.bean.Artist_Master;
import com.cg.mcam.bean.Composer_Master;
import com.cg.mcam.bean.Song_Master;
import com.cg.mcam.exception.MediaException;
import com.cg.mcam.service.MediaService;
import com.cg.mcam.service.MediaServiceImpl;

public class MediaMain 

{
	static Scanner sc=null;
	static MediaService medSer=null;

	public static void main(String[] args) throws MediaException 
	{

		medSer= new MediaServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("*************WELCOME TO MEDIA COMPOSER AND ARTIST MANAGEMENT SYSTEM***********");
			System.out.println(" \n \t 1: Add a new  Song of your choice  \n  \t 2: Fetch all songs  \n \t 3: Delete Song \n \t 4: Find Song from Song Id  \n  \t 5: Add Composer \n \t 6: Find Composer \n \t 7: Add Artist \n t 8: Find Artist ");

			int choice=sc.nextInt();
			switch(choice)
			{

			case 1: InsertSong();
			break;

			case 2: FetchSongs();
			break;

			case 3: DeleteSong();
			break;

			case 4: GetSong();
			break;			

			case 6: AddComposer();
			break;	

			case 7: FindComposer();
			break;	

			case 8: AddArtist();
			break;	

			case 5: FindArtist();
			break;	

			default: System.out.println("Thank you Please visit again");
			System.exit(0);   
			}



		}

	}


	







	/*******************************************Find Composer********************************************/

	private static void FindComposer() 
	{
		System.out.println("Enter the composer id: ");
		int composer_Id=sc.nextInt();

		Composer_Master compBean= new Composer_Master();
		try
		{
			compBean=medSer.getComposer(composer_Id);
			if(compBean !=null)
			{
				System.out.println(compBean.getComposer_Id());
				System.out.println(compBean.getComposer_Name());
				System.out.println(compBean.getComposer_Born_Date());
				System.out.println(compBean.getComposer_Died_Date());
				System.out.println(compBean.getComposer_Caeipi_Number());
				System.out.println(compBean.getCreated_by());
				System.out.println(compBean.getUpdated_by());		
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}

	}






	/********************************************Add artist************************************************/	


	private static void AddArtist() throws MediaException 
	{
		System.out.println(" Enter the Artist Name : ");
		String artistName=sc.next();

		
		System.out.println("Enter the Artist type: ");
		String artisttype=sc.next();
		
		System.out.println(" Enter the Artist Birth Date : ");
		String artistBirthDate=sc.next();

		System.out.println(" Created By: ");
		int createdBy=sc.nextInt();

		System.out.println(" Updated By: ");
		int updatedBy=sc.nextInt();


		Artist_Master am=new Artist_Master();
		am.setArtist_Name(artistName);
		am.setArtist_Type(artisttype);
		am.setArtist_Born_Date(artistBirthDate);
		am.setCreated_By(createdBy);
		am.setUpdated_By(updatedBy);

		int ArtistAdded=medSer.addArtist(am);

		if(ArtistAdded==1)
		{
			System.out.println("Artist Added successfully");
		}
		else
		{

			System.out.println("Artist couldnt be added");
		}
		
	}


	/****************************************** Find Artist************************************************/	



	private static void FindArtist() 
	{
		
		System.out.println("Enter the Artist id: ");
		int artist_Id=sc.nextInt();

		Artist_Master artistBean= new Artist_Master();
		try
		{
			artistBean=medSer.getArtist(artist_Id);
			if(artistBean !=null)
			{
				System.out.println(artistBean.getArtist_Id());
				System.out.println(artistBean.getArtist_Name());
				System.out.println(artistBean.getArtist_Type());
				System.out.println(artistBean.getArtist_Born_Date());
				System.out.println(artistBean.getArtist_Died_Date());
				System.out.println(artistBean.getCreated_By());
				System.out.println(artistBean.getUpdated_By());		
			}
		}
		catch(Exception e)
		{
			e.getMessage();
		}
		
	}




	/*********************************************FetchSong from song ID***************************************************/	



	private static void GetSong()

	{
		Song_Master sm2= new Song_Master();
		System.out.println("Enter the song id: ");
		int song_id=sc.nextInt();

		if(sm2.getSong_name()==null)
		{
			System.out.println("Details not found. ");

		}
		else
		{
			System.out.println(sm2);
		}

	}

	/**********************************************Add Compose *****************************************************/	
	private static void AddComposer() throws MediaException 

	{
		System.out.println(" Enter the Composer Name : ");
		String composerName=sc.next();

		System.out.println(" Enter the Composer Birth Date : ");
		String composerBirthDate=sc.next();

		System.out.println("Enter the Composer Caeipi Number: ");
		String ComposerCaNo=sc.next();

		System.out.println(" Created By: ");
		int createdBy=sc.nextInt();

		System.out.println(" Updated By: ");
		int updatedBy=sc.nextInt();


		Composer_Master cm=new Composer_Master();
		cm.setComposer_Name(composerName);
		cm.setComposer_Born_Date(composerBirthDate);
		cm.setComposer_Caeipi_Number(ComposerCaNo);
		cm.setCreated_by(createdBy);
		cm.setUpdated_by(updatedBy);

		int composerAdded=medSer.addComposer(cm);

		if(composerAdded==1)
		{
			System.out.println("Composer Added successfully");
		}
		else
		{

			System.out.println("Composer couldnt be added");
		}

	}
	/*********************************************Delete Song****************************************************/	

	private static void DeleteSong() 
	{
		System.out.println(" Enter the song id for the song to be deleted:  ");
		int songId=sc.nextInt();


		try
		{
			int songDeleted = medSer.deleteSong(songId);
			if(songDeleted==1)
			{
				System.out.println("Song deleted");
			}
			else
			{
				System.out.println("Soryy!! Song not deleted");
			}
		}
		catch(MediaException e)
		{
			System.out.println(e.getMessage());
		}

	}
	/*********************************************Fetch Songs***********************************************************/	
	private static void FetchSongs()
	{
		try
		{
			ArrayList<Song_Master> songsList=medSer.getAllSongs();

			for(Song_Master sm:songsList)
			{
				System.out.println(sm);
			}
		}
		catch (Exception e) 
		{
			System.out.println(" Some error occured while fetching Songs. ");
		}


	}

	/***********************************************Insert a new Song****************************************************/

	private static void InsertSong() throws MediaException 
	{
		System.out.println(" Enter the Song Name: ");
		String songName=sc.next();

		System.out.println(" Enter the song duration: ");
		String songDuration=sc.next();

		System.out.println(" Created By: ");
		int createdBy=sc.nextInt();

		System.out.println(" Updated By: ");
		int updatedBy=sc.nextInt();


		Song_Master sm=new Song_Master();
		sm.setSong_name(songName);
		sm.setSong_duration(songDuration);
		sm.setCreated_by(createdBy);
		sm.setUpdated_by(updatedBy);

		int songAdded=medSer.addSongs(sm);

		if(songAdded==1)
		{
			System.out.println("Song Successfully Added");
		}
		else
		{

			System.out.println("Some error occured while adding song");
		}

	}

}
