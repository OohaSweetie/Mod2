package com.cg.rd.dto;

public class Device {
	private int  devId;
	private String  title;
	private double price;
	private Category  category;
	private String manufacturer;
	
	
	public int getDevId() {
		return devId;
	}
	public void setDevId(int devId) {
		this.devId = devId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public Device(int devId, String title, double price, Category category,
			String manufacturer) {
		super();
		this.devId = devId;
		this.title = title;
		this.price = price;
		this.category = category;
		this.manufacturer = manufacturer;
	}
	public Device() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Contact [devId=" + devId + ", title=" + title + ", price="
				+ price + ", category=" + category + ", manufacturer="
				+ manufacturer + "]";
	}
	
	

}
