package com.cg.rd.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.rd.dao.IDeviceDao;
import com.cg.rd.dao.DeviceDaoImpl;
import com.cg.rd.dto.Category;
import com.cg.rd.dto.Device;
import com.cg.rd.exception.DeviceException;

@SuppressWarnings("unused")
public class DeviceServiceImpl implements IDeviceService {

	private IDeviceDao dao = null;

	private List<String> validationErrors;

	public DeviceServiceImpl() throws DeviceException {
		dao = new DeviceDaoImpl();
	}

	public boolean isValidContact(Device contact) {
		validationErrors = new ArrayList<>();
		if (contact != null) {

		}

		return validationErrors.size() == 0 ? true : false;
	}

	@Override
	public int add(Device contact) throws DeviceException {
		int result = -1;
		if (isValidContact(contact)) {
			result = dao.add(contact);
		} else {
			throw new DeviceException("Can't have Invalid Student!"
					+ validationErrors);
		}
		return result;
	}

	@Override
	public List<Device> getAllByCategory(Category crg) throws DeviceException {
		return dao.getAllByCategory(crg);
	}
}
