package com.cg.rd.service;

import java.util.List;



import com.cg.rd.dto.Category;
import com.cg.rd.dto.Device;
import com.cg.rd.exception.DeviceException;

public interface IDeviceService {
	public int add(Device contact) throws DeviceException;
	public List<Device> getAllByCategory(Category crg) throws DeviceException;
}