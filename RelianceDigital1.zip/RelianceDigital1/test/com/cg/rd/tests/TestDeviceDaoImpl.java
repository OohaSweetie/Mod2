
package com.cg.rd.tests;

import static org.junit.Assert.*;

import org.apache.log4j.PropertyConfigurator;
import org.junit.Before;
import org.junit.Test;

import com.cg.rd.dao.IDeviceDao;
import com.cg.rd.dao.DeviceDaoImpl;
import com.cg.rd.dto.Category;
import com.cg.rd.dto.Device;
import com.cg.rd.exception.DeviceException;

public class TestDeviceDaoImpl {

	IDeviceDao dao = null;

	@Before
	public void setUp() throws Exception {
		PropertyConfigurator.configure("res/log4j.properties");
		dao = new DeviceDaoImpl();

	}

	@Test
	public void testAddNullTitle() {
		try {
			Device input = null;
			int expected = -1;
			int actual = dao.add(input);
			assertTrue(expected == actual);
		} catch (DeviceException exp) {
			fail("This not an expected exception");
		}
	}

	@Test
	public void testAddNotNullDevice() {
		try {
			Device input = new Device();
			input.setTitle("vivo");
			input.setPrice(37000);
			input.setCategory(Category.LAPTOP);
			input.setManufacturer("HP");

			int expected = 1;
			int actual = dao.add(input);
			assertTrue(expected == actual);
		} catch (DeviceException exp) {
System.err.print(exp);
		}
	}
}
