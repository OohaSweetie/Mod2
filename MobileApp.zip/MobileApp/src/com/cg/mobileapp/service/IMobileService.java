package com.cg.mobileapp.service;

import java.util.List;

import com.cg.mobileapp.dto.Mobile;


public interface IMobileService {
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobiles();
	public void updateMobile(Mobile mob);
	public void deleteMobile(int mobId);
}
