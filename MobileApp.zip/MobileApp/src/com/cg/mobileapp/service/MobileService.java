package com.cg.mobileapp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mobileapp.dao.IMobileDao;
import com.cg.mobileapp.dto.Mobile;

@Service("mobileservice")
@Transactional
public class MobileService implements IMobileService {
	@Autowired
	IMobileDao mobiledao;
	@Override
	public void addMobileData(Mobile mob) {
		// TODO Auto-generated method stub
		mobiledao.addMobileData(mob);
	}
	@Override
	public List<Mobile> showAllMobiles() {
		// TODO Auto-generated method stub
		return mobiledao.showAllMobiles();
	}
	@Override
	public void updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		mobiledao.deleteMobile(mobId);
		
	}

}
