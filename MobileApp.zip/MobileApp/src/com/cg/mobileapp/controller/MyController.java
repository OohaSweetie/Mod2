package com.cg.mobileapp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobileapp.dto.Mobile;
import com.cg.mobileapp.service.IMobileService;
@Controller
public class MyController {
	@Autowired
	IMobileService mobileservice;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";	
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addMobile(@ModelAttribute("my") Mobile mob,Map<String,Object> model)
	{
		List<String> myCat=new ArrayList<>();
		myCat.add("RedMi");
		myCat.add("iphone");
		myCat.add("samsung");
		model.put("category", myCat);
		return "addmobile";
	}
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String insertMobile(@ModelAttribute("my") Mobile mob)
	{
		mobileservice.addMobileData(mob);
		
		return "success";
		
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Mobile> myAllData=mobileservice.showAllMobiles();
		return new ModelAndView("showall","temp",myAllData);
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String mobileDelete(@RequestParam("id") int mobid)
	{
		System.out.println("id is "+mobid);
		mobileservice.deleteMobile(mobid);
		return "redirect:/showall";
		
	}
}
