package com.cg.mobpur.bean;


public class Purchase 
{
private String cName;
private int purchaseId;
private String mailId;
private long phoneNo;
private int mobileId;
public Purchase(String cName, int purchaseId, String mailId, long phoneNo,
		int mobileId) {
	super();
	this.cName = cName;
	this.purchaseId = purchaseId;
	this.mailId = mailId;
	this.phoneNo = phoneNo;
	this.mobileId = mobileId;
}
public Purchase() {
	super();
	// TODO Auto-generated constructor stub
}
public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
public int getPurchaseId() {
	return purchaseId;
}
public void setPurchaseId(int purchaseId) {
	this.purchaseId = purchaseId;
}
public String getMailId() {
	return mailId;
}
public void setMailId(String mailId) {
	this.mailId = mailId;
}
public long getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(long phoneNo) {
	this.phoneNo = phoneNo;
}
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}
@Override
public String toString() {
	return "Purchase [cName=" + cName + ", purchaseId=" + purchaseId
			+ ", mailId=" + mailId + ", phoneNo=" + phoneNo + ", mobileId="
			+ mobileId + "]";
}

}
