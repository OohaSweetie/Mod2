package com.cg.mobpur.dao;

import java.util.ArrayList;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;



public interface MobDao 
{
	public int generatepurchaseId()throws MobileException;
	public int addpurchasedetails(Purchase ps)throws MobileException;
	public ArrayList<Mobile>getAllMob()throws MobileException;
	public ArrayList<Integer>generateMobId()throws MobileException;
	public int generateMobQuantity(Purchase ps)throws MobileException;
	public int updateQuantity(int mobileId) throws MobileException;
	public int deleteMobiles(int mobileId) throws MobileException;
	public ArrayList<Mobile> getMobilesInRange(float min, float max)throws MobileException;
	
}
