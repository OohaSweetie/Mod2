package com.cg.mobpur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobpur.util.DBUtil;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;

public class MobDaoImpl implements MobDao 
{
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Connection con=null;
	Scanner sc=new Scanner(System.in);
	Logger mobLogger=null;
	public MobDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties"); 
		mobLogger=Logger.getLogger("MobileDaoImpl.class");
	}
	@Override
	public int generatepurchaseId() throws MobileException 
	{
		
		String qry="SELECT pur_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(qry);
		rs.next();
	    generatedVal=rs.getInt(1);
		
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try {
				rs.close();
				st.close();
				con.close();
			} catch (SQLException e) {
				
				throw new MobileException(e.getMessage());
		}
		}
		return generatedVal;
		
	}
	@Override
	public int addpurchasedetails(Purchase ps) throws MobileException 
	{
		String insertQry=" INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid)VALUES(?,?,?,?,sysdate,?)";
		int dataAdded=0;
		try{
		
		con=DBUtil.getCon();
		pst=con.prepareStatement(insertQry);
		pst.setInt(1, generatepurchaseId());
		pst.setString(2, ps.getcName());
		pst.setString(3,ps.getMailId());
		pst.setLong(4,ps.getPhoneNo());
		pst.setInt(5,ps.getMobileId());
		dataAdded=pst.executeUpdate();
		mobLogger.info("purchasedetails inserted "+ps);
		}
	
		catch(Exception e)
		{
			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
		        pst.close();
				con.close();
			    } 
			catch (SQLException e) 
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
			}
		}
		
		return dataAdded;
	}
	@Override
	public ArrayList<Mobile> getAllMob() throws MobileException
	{
		ArrayList<Mobile>mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile mob=null;
		try{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			mobLogger.info("ALL MOBILE RECORDS ARE");
			while(rs.next())
			{
				mob=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mob);	
				mobLogger.info(mob);
			}
			
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		
		finally
		{
			try {
				rs.close();
				st.close();
				con.close();
			} catch (SQLException e) 
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
		}
		}
		
		
		return mobList;
	}
	
	@Override
	public ArrayList<Integer> generateMobId() throws MobileException 
	{
		
		String selectqry="SELECT mobileId FROM mobiles";
		ArrayList<Integer>mobList=new ArrayList<Integer>();
		int mobId;
		try
		{
		con=DBUtil.getCon();
		st=con.createStatement();
		rs=st.executeQuery(selectqry);
		
		while(rs.next())
		{
		mobId=rs.getInt(1);
	    mobList.add(mobId);
		}
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				
				throw new MobileException(e.getMessage());
		    }
		}
		return mobList;
	}
	
	@Override
	public int generateMobQuantity(Purchase ps) throws MobileException {
			String selectqry="SELECT quantity FROM mobiles WHERE mobileId=?";
			int quantity=0;
			try{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectqry);
			pst.setInt(1,ps.getMobileId());
			rs=pst.executeQuery();
			rs.next();
			quantity=rs.getInt(1);
			}
			catch(Exception e)
			{
				throw new MobileException(e.getMessage());
			}
			finally
			{
				try {
					rs.close();
					pst.close();
					con.close();
				} catch (SQLException e) 
				{
					
					throw new MobileException(e.getMessage());
			}
			}
			return quantity;
			}
	@Override
	public int updateQuantity(int mobileId) throws MobileException 
	{
		String updateqry="UPDATE mobiles SET quantity=quantity-1 WHERE mobileId=?";
		int dataUpdated;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateqry);
			pst.setInt(1,mobileId);
			dataUpdated=pst.executeUpdate();
			 mobLogger.info("Number of rows updates are "+dataUpdated);
		}
		
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try {
				pst.close();
				con.close();
			} catch (SQLException e) 
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
		}
		}
		return dataUpdated;
		}
	@Override
	public int deleteMobiles(int mobileid) throws MobileException {
		String deleteqry="DELETE FROM mobiles WHERE mobileId=?";
		int datadeleted=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteqry);
			pst.setInt(1,mobileid);
			datadeleted=pst.executeUpdate();
			mobLogger.info("Number of rows deleted are "+datadeleted);
		}
		
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try {
				pst.close();
				con.close();
			} catch (SQLException e) 
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
		}
		}
		return datadeleted;
	}
	@Override
	public ArrayList<Mobile> getMobilesInRange(float min, float max)throws MobileException {
		String selectqry="SELECT * FROM mobiles WHERE price between ? and ?";
		ArrayList<Mobile>mobList=new ArrayList<Mobile>();
		Mobile mob=null;
		try{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectqry);
			pst.setFloat(1, min);
			pst.setFloat(2, max);
			rs=pst.executeQuery();
			mobLogger.info("SELECTED RECORDS ARE");
			while(rs.next())
			{
				mob=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mob);		
			}
			
		}
		catch(Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		
		finally
		{
			try {
				
				pst.close();
				con.close();
			} catch (SQLException e)
			{
				mobLogger.error("This is exception :"+e.getMessage());
				throw new MobileException(e.getMessage());
		}
		}
		
		
		return mobList;
	}
	
}


		