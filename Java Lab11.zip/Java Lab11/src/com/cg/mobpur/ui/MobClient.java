package com.cg.mobpur.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.exception.MobileException;
import com.cg.mobpur.service.MobService;
import com.cg.mobpur.service.MobServiceImp1;

public class MobClient 
{
   static Scanner sc=null;
   static MobService mobSer=null;
   public static void main(String[] args) 
   {
	  mobSer=new MobServiceImp1();
	  sc=new Scanner(System.in);
	  int choice=0;
	  while(true)
      {
		 System.out.println("What do you want to do?");
		 System.out.println("1.Add Purchases\t 2.FetchAllMobiles\t 3.deleteMobiles \t 4.ViewInRange \t5.Exit");
          choice=sc.nextInt();
		 switch(choice)
		   {
		       case 1:
		         insertPurchases();
		         break;
		        case 2:
		          FetchAllMobiles();
		          break;
		        case 3:
		          deleteMobiles();
		           break;
		        case 4:
		        	ViewInRange();
		        	break;
		        default:
		           System.exit(0);
		     }
	    }
   }
	
public static void ViewInRange() 
{
	float min=0;
	float max=0;
	 System.out.println("Enter minimum range");
	 min=sc.nextFloat();
	 System.out.println("Enter maximum range");
	 max=sc.nextFloat();
	 try
	 {
			ArrayList<Mobile>mobList=mobSer.getMobilesInRange(min,max);
		    for(Mobile mob:mobList)
			{
			  System.out.println(mob);
						
			} 
	 }
	 catch(MobileException e)
		{
		System.out.println(e.getMessage());
		}
}

public static void deleteMobiles() 
{
				
    System.out.println("Enter mobile Id to be deleted:");
    int mid=sc.nextInt();
	   try
	     {
		   Mobile mb=new Mobile();
		   mb.setMobileid(mid);
	       int datadeleted=mobSer.deleteMobiles(mid);
	       if(datadeleted==1)
	          {
		         System.out.println("Data is deleted");
	          }
          else
	        {
	           System.out.println("some exceptions may be encountered");
            }
	      }
	    catch(MobileException e)
	     {
	       System.out.println(e.getMessage());
	     }
}	

public static void FetchAllMobiles() 
{
    try
	 {
	   ArrayList<Mobile>mobList=mobSer.getAllMob();
       for(Mobile mob:mobList)
	     {
	       System.out.println(mob);
				
	     }
	  }
         catch(MobileException e)
	        {
	         System.out.println(e.getMessage());
	        }
}
public static void insertPurchases() 
{
    System.out.println("Enter customer name");
    String cnm=sc.next();
    System.out.println("Enter customer mail id ");
    String mailId=sc.next();
    System.out.println("Enter customer phone number");
    long phoneNo=sc.nextLong();
    System.out.println("Enter Mobile Id");
    int mId=sc.nextInt();
    try 
      {
        if(mobSer.validateName(cnm) && mobSer.validateMailId(mailId) && mobSer.validatePhoneNo(phoneNo) && mobSer.validateMobileId(mId))
           {
                int dataAdded = 0;
                Purchase ps=new Purchase();
                ps.setcName(cnm);
                ps.setMailId(mailId);
                ps.setPhoneNo(phoneNo);
                ps.setMobileId(mId);
                if(mobSer.validategenerateMobQuantity(ps))
                  {
                     dataAdded = mobSer.addpurchasedetails(ps);
                   }
                    if(dataAdded==1)
                      {
                        System.out.println(" data added");
                         UpdateMobiles(mId);
                
                       }
                     else
                     {
                       System.out.println("Some exception may be encountered while insertion");
                
      
                      }
               }
           } 
catch (MobileException e)
    {
        
        System.out.println(e.getMessage());
    }
}
public static void UpdateMobiles(int mId) 
{
    Purchase ps=new Purchase();
    int rows=0;
	try
	  {
		 rows=mobSer.updateQuantity(mId);
		 if(rows>0)
		 {
		   System.out.println(rows+"rows updated");
		 }
		 else
		 {
		    System.out.println("some exceptions may be encountered");
		 }
		    		
	  }
catch(MobileException e)
{
   System.out.println(e.getMessage());
}
				
}
}
    
			