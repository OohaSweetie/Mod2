package com.cg.mobpur.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobpur.bean.Mobile;
import com.cg.mobpur.bean.Purchase;
import com.cg.mobpur.dao.MobDao;
import com.cg.mobpur.dao.MobDaoImpl;
import com.cg.mobpur.exception.MobileException;

public class MobDaoImplTest
{
	    static MobDao mobDao=null;
	    static Mobile mob=null;
	    static Purchase ps=null;
	    @Test
	    public void testAddMob1() throws MobileException
	    {
	        Assert.assertEquals(1,mobDao.addpurchasedetails(ps));
	    }
	    @Test(expected=Exception.class)
	    public void testAddMob2() throws MobileException
	    {
	        Assert.assertEquals(1,mobDao.addpurchasedetails(ps));
	    }
	    @Test
	    public void testSelectMob1() throws MobileException
	    {
	        Assert.assertNotNull(mobDao.getAllMob());
	    }
	    public void testSelectMob2() throws MobileException
	    {
	        Assert.assertNotNull(mobDao.getMobilesInRange(5000,20000));
	    }
	    public void testUpdate1() throws MobileException
	    {
	        Assert.assertEquals(1,mobDao.updateQuantity(1004));
	    }
	    @Test(expected=Exception.class)
	    public void testUpdate2() throws MobileException
	    {
	        Assert.assertEquals(0,mobDao.updateQuantity(1234));
	    }
	    public void testDelete1() throws MobileException
	    {
	        Assert.assertEquals(1,mobDao.deleteMobiles(1004));
	    }
	    @Test(expected=Exception.class)
	    public void testDelete2() throws MobileException
	    {
	        Assert.assertEquals(0,mobDao.deleteMobiles(1234));
	    }
	    
	}
